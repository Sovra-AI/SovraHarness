// invoice total = 93
const total = 93;
